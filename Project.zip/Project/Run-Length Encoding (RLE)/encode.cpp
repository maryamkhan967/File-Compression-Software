#include <iostream>
#include <fstream>
#include <string>

using namespace std;

void runLengthEncode(const string& inputFile, const string& outputFile) {
    ifstream inFile(inputFile);
    ofstream outFile(outputFile);
    if (!inFile || !outFile) {
        cerr << "Error opening files!" << endl;
        return;
    }

    char currentChar, previousChar;
    int count = 0;

    inFile.get(previousChar);
    count = 1;

    while (inFile.get(currentChar)) {
        if (currentChar == previousChar && count < 255) {
            count++;
        } else {
            outFile << previousChar << ":" << count << " ";
            previousChar = currentChar;
            count = 1;
        }
    }

    if (count > 0) {
        outFile << previousChar << ":" << count << " ";
    }

    inFile.close();
    outFile.close();
    cout << "File encoded successfully as " << outputFile << endl;
}

int main(int argc, char* argv[]) {
    if (argc != 3) {
        cerr << "Usage: " << argv[0] << " inputFile.txt outputFile.txt" << endl;
        return 1;
    }

    runLengthEncode(argv[1], argv[2]);
    return 0;
}
