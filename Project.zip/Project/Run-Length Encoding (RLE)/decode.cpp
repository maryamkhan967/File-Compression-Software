#include <iostream>
#include <fstream>
#include <string>

using namespace std;

void runLengthDecode(const string& inputFile, const string& outputFile) {
    ifstream inFile(inputFile);
    ofstream outFile(outputFile);
    if (!inFile || !outFile) {
        cerr << "Error opening files!" << endl;
        return;
    }

    char character;
    unsigned char count;

    while (inFile.get(character) && inFile.get(reinterpret_cast<char&>(count))) {
        for (int i = 0; i < count; i++) {
            outFile.put(character);
        }
    }

    inFile.close();
    outFile.close();
    cout << "File decoded successfully as " << outputFile << endl;
}

int main(int argc, char* argv[]) {
    if (argc != 3) {
        cerr << "Usage: " << argv[0] << " inputFile.txt outputFile.txt" << endl;
        return 1;
    }

    runLengthDecode(argv[1], argv[2]);
    return 0;
}
